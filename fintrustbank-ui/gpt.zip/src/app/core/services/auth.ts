// src/app/core/services/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { AccountService } from './account';
import { TransactionService } from './transaction';
import { AdminService } from './admin';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = environment.apiUrl;

  constructor(
    private http: HttpClient,
    private router: Router,
    private accountService: AccountService,
    private transactionService: TransactionService,
    private adminService: AdminService
  ) {}

  register(data: any) {
    return this.http.post(`${this.api}/auth/register`, data);
  }

  login(data: any) {
    return this.http.post<any>(`${this.api}/auth/login`, data);
  }

  changePassword(data: any) {
    return this.http.put(`${this.api}/auth/change-password`, data);
  }

  saveSession(data: any) {
    localStorage.setItem('token', data.token);
    // Fixed: store token separately, don't duplicate it inside 'user'
    const { token, ...userData } = data;
    localStorage.setItem('user', JSON.stringify(userData));
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getUser(): any {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  isAdmin(): boolean {
    return this.getUser()?.role === 'Admin';
  }

  logout() {
    // Clear all in-memory caches so a new user session starts fresh
    this.accountService.clearAccountsCache();
    this.adminService.clearAllCaches();
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}