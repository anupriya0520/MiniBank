// src/app/core/services/account.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AccountService {
  private api = environment.apiUrl;

  // In-memory cache — persists for the lifetime of the app session
  private accountsCache: any = null;
  private beneficiariesCache: Map<number, any> = new Map();

  constructor(private http: HttpClient) {}

  getMyAccounts(): Observable<any> {
    // Return cached value instantly if available
    if (this.accountsCache) {
      return of(this.accountsCache);
    }
    return this.http.get<any>(`${this.api}/accounts`).pipe(
      tap(res => this.accountsCache = res)
    );
  }

  // Call this after deposit, pin change etc. to force a fresh fetch next time
  clearAccountsCache() {
    this.accountsCache = null;
  }

  deposit(accountId: number, data: any): Observable<any> {
    return this.http.post<any>(`${this.api}/accounts/${accountId}/deposit`, data).pipe(
      tap(() => this.clearAccountsCache()) // balance changed — invalidate cache
    );
  }

  setTransferPin(accountId: number, data: any): Observable<any> {
    return this.http.post<any>(`${this.api}/accounts/${accountId}/set-transfer-pin`, data).pipe(
      tap(() => this.clearAccountsCache())
    );
  }

  updateTransferPin(accountId: number, data: any): Observable<any> {
    return this.http.put<any>(`${this.api}/accounts/${accountId}/update-transfer-pin`, data).pipe(
      tap(() => this.clearAccountsCache())
    );
  }

  getBeneficiaries(accountId: number): Observable<any> {
    if (this.beneficiariesCache.has(accountId)) {
      return of(this.beneficiariesCache.get(accountId));
    }
    return this.http.get<any>(`${this.api}/accounts/${accountId}/beneficiaries`).pipe(
      tap(res => this.beneficiariesCache.set(accountId, res))
    );
  }

  addBeneficiary(accountId: number, data: any): Observable<any> {
    return this.http.post<any>(`${this.api}/accounts/${accountId}/beneficiaries`, data).pipe(
      tap(() => this.beneficiariesCache.delete(accountId)) // invalidate this account's beneficiaries
    );
  }

  deleteBeneficiary(accountId: number, beneficiaryId: number): Observable<any> {
    return this.http.delete<any>(`${this.api}/accounts/${accountId}/beneficiaries/${beneficiaryId}`).pipe(
      tap(() => this.beneficiariesCache.delete(accountId)) // invalidate this account's beneficiaries
    );
  }
}