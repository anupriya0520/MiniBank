// src/app/core/services/admin.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AdminService {
  private api = environment.apiUrl;

  private dashboardCache:    any = null;
  private pendingKycCache:   any = null;
  private allKycCache:       any = null;
  private allAccountsCache:  any = null;
  private allTransactionsCache: any = null;
  private auditLogsCache:    any = null;

  constructor(private http: HttpClient) {}

  getDashboard(): Observable<any> {
    if (this.dashboardCache) return of(this.dashboardCache);
    return this.http.get<any>(`${this.api}/admin/dashboard`).pipe(
      tap(res => this.dashboardCache = res)
    );
  }

  getPendingKyc(): Observable<any> {
    if (this.pendingKycCache) return of(this.pendingKycCache);
    return this.http.get<any>(`${this.api}/admin/kyc/pending`).pipe(
      tap(res => this.pendingKycCache = res)
    );
  }

  getAllKyc(): Observable<any> {
    if (this.allKycCache) return of(this.allKycCache);
    return this.http.get<any>(`${this.api}/admin/kyc`).pipe(
      tap(res => this.allKycCache = res)
    );
  }

  reviewKyc(kycId: number, data: any): Observable<any> {
    return this.http.put<any>(`${this.api}/admin/kyc/${kycId}/review`, data).pipe(
      tap(() => {
        // KYC data changed — invalidate all KYC caches
        this.pendingKycCache = null;
        this.allKycCache     = null;
        this.dashboardCache  = null;
      })
    );
  }

  getAllAccounts(): Observable<any> {
    if (this.allAccountsCache) return of(this.allAccountsCache);
    return this.http.get<any>(`${this.api}/admin/accounts`).pipe(
      tap(res => this.allAccountsCache = res)
    );
  }

  deactivateAccount(accountId: number): Observable<any> {
    return this.http.put<any>(`${this.api}/admin/accounts/${accountId}/deactivate`, {}).pipe(
      tap(() => {
        this.allAccountsCache = null;
        this.dashboardCache   = null;
      })
    );
  }

  getAllTransactions(): Observable<any> {
    if (this.allTransactionsCache) return of(this.allTransactionsCache);
    return this.http.get<any>(`${this.api}/admin/transactions`).pipe(
      tap(res => this.allTransactionsCache = res)
    );
  }

  flagTransaction(transactionId: number, data: any): Observable<any> {
    return this.http.put<any>(`${this.api}/admin/transactions/${transactionId}/flag`, data).pipe(
      tap(() => this.allTransactionsCache = null)
    );
  }

  getAuditLogs(): Observable<any> {
    if (this.auditLogsCache) return of(this.auditLogsCache);
    return this.http.get<any>(`${this.api}/admin/audit-logs`).pipe(
      tap(res => this.auditLogsCache = res)
    );
  }

  // Call this on admin logout to wipe all cached admin data
  clearAllCaches() {
    this.dashboardCache       = null;
    this.pendingKycCache      = null;
    this.allKycCache          = null;
    this.allAccountsCache     = null;
    this.allTransactionsCache = null;
    this.auditLogsCache       = null;
  }
}