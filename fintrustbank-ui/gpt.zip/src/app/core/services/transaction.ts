// src/app/core/services/transaction.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class TransactionService {
  private api = environment.apiUrl;

  // Cache per accountId — Map<accountId, response>
  private historyCache: Map<number, any> = new Map();

  constructor(private http: HttpClient) {}

  getHistory(accountId: number): Observable<any> {
    if (this.historyCache.has(accountId)) {
      return of(this.historyCache.get(accountId));
    }
    return this.http.get<any>(`${this.api}/accounts/${accountId}/transactions`).pipe(
      tap(res => this.historyCache.set(accountId, res))
    );
  }

  // After any write operation, invalidate that account's transaction cache
  // so the next visit fetches fresh data with the new transaction included
  clearHistoryCache(accountId: number) {
    this.historyCache.delete(accountId);
  }

  withdraw(accountId: number, data: any): Observable<any> {
    return this.http.post<any>(`${this.api}/accounts/${accountId}/transactions/withdraw`, data).pipe(
      tap(() => this.clearHistoryCache(accountId))
    );
  }

  transferToAccount(accountId: number, data: any): Observable<any> {
    return this.http.post<any>(`${this.api}/accounts/${accountId}/transactions/transfer/account`, data).pipe(
      tap(() => this.clearHistoryCache(accountId))
    );
  }

  transferToPhone(accountId: number, data: any): Observable<any> {
    return this.http.post<any>(`${this.api}/accounts/${accountId}/transactions/transfer/phone`, data).pipe(
      tap(() => this.clearHistoryCache(accountId))
    );
  }

  transferToBeneficiary(accountId: number, data: any): Observable<any> {
    return this.http.post<any>(`${this.api}/accounts/${accountId}/transactions/transfer/beneficiary`, data).pipe(
      tap(() => this.clearHistoryCache(accountId))
    );
  }
}