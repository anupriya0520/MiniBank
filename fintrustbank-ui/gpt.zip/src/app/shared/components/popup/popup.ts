// src/app/shared/components/popup/popup.component.ts
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-popup',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './popup.html',
  styleUrl: './popup.css'
})
export class PopupComponent {
  @Input() visible:     boolean = false;
  @Input() type:        'success' | 'error' | 'warning' | 'confirm' = 'success';
  @Input() title:       string = '';
  @Input() message:     string = '';
  @Input() confirmText: string = 'Confirm';
  @Input() cancelText:  string = 'Cancel';
  @Input() showCancel:  boolean = false;

  @Output() onConfirm = new EventEmitter<void>();
  @Output() onCancel  = new EventEmitter<void>();
  @Output() onClose   = new EventEmitter<void>();

  // Fixed: only emit — parent (app.html) controls visibility via popupService.close()
  // Previously this.visible = false mutated an @Input() which breaks one-way data flow
  // Previously confirm()/cancel() called close() causing onClose to fire on every confirm/cancel

  close() {
    this.onClose.emit();
  }

  confirm() {
    this.onConfirm.emit();
  }

  cancel() {
    this.onCancel.emit();
  }
}