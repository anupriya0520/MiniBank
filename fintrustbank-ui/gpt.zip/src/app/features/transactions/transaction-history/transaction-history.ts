// src/app/features/transactions/transaction-history/transaction-history.component.ts
import { Component, inject, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { switchMap, takeUntil } from 'rxjs/operators';
import { TransactionService } from '../../../core/services/transaction';
import { AccountService } from '../../../core/services/account';
import { PopupService } from '../../../core/services/popup';

@Component({
  selector: 'app-transaction-history',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './transaction-history.html',
  styleUrl: './transaction-history.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TransactionHistoryComponent implements OnInit, OnDestroy {
  transactionService = inject(TransactionService);
  accountService     = inject(AccountService);
  popupService       = inject(PopupService);
  route              = inject(ActivatedRoute);
  cdr                = inject(ChangeDetectorRef);

  accounts: any[]          = [];
  transactions: any[]      = [];
  selectedAccountId: number | null = null;
  loading          = false;
  loadingAccounts  = true;

  private accountChange$ = new Subject<number>();
  private destroy$       = new Subject<void>();

  ngOnInit() {
    // switchMap cancels the previous HTTP call when account changes — prevents stale data
    this.accountChange$.pipe(
      switchMap(id => {
        this.loading = true;
        this.cdr.markForCheck();
        return this.transactionService.getHistory(id);
      }),
      takeUntil(this.destroy$)
    ).subscribe({
      next: (res: any) => {
        // Pre-map labels/classes here so the template never calls functions per row
        this.transactions = (res.data || []).map((tx: any) => ({
          ...tx,
          typeLabel:   this.getTxTypeLabel(tx.type),
          typeClass:   this.getTxTypeClass(tx.type),
          statusLabel: this.getTxStatusLabel(tx.status),
          statusClass: this.getTxStatusClass(tx.status),
          isCredit:    tx.type === 1 || tx.type === 4
        }));
        this.loading = false;
        this.cdr.markForCheck();
      },
      error: () => {
        this.loading = false;
        this.cdr.markForCheck();
        this.popupService.error('Error', 'Failed to load transactions.');
      }
    });

    this.accountService.getMyAccounts().subscribe({
      next: (res: any) => {
        this.accounts        = res.data || [];
        this.loadingAccounts = false;

        const accountId = this.route.snapshot.queryParams['accountId'];
        this.selectedAccountId = accountId
          ? +accountId
          : this.accounts[0]?.id ?? null;

        if (this.selectedAccountId) {
          this.accountChange$.next(this.selectedAccountId);
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.loadingAccounts = false;
        this.cdr.markForCheck();
        this.popupService.error('Error', 'Failed to load accounts.');
      }
    });
  }

  onAccountChange(event: any) {
    this.selectedAccountId = +event.target.value;
    this.accountChange$.next(this.selectedAccountId);
  }

  trackById(index: number, item: any): number {
    return item.id ?? index;
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // These are only called once per transaction on load, not on every render cycle
  private getTxTypeLabel(type: number): string {
    const map: any = { 1: 'Deposit', 2: 'Withdrawal', 3: 'Transfer Out', 4: 'Transfer In' };
    return map[type] || 'Unknown';
  }

  private getTxTypeClass(type: number): string {
    const map: any = { 1: 'badge-success', 2: 'badge-danger', 3: 'badge-warning', 4: 'badge-info' };
    return map[type] || 'badge-muted';
  }

  private getTxStatusLabel(status: number): string {
    const map: any = { 1: 'Pending', 2: 'Completed', 3: 'Failed', 4: 'Flagged' };
    return map[status] || 'Unknown';
  }

  private getTxStatusClass(status: number): string {
    const map: any = { 1: 'badge-warning', 2: 'badge-success', 3: 'badge-danger', 4: 'badge-danger' };
    return map[status] || 'badge-muted';
  }
}