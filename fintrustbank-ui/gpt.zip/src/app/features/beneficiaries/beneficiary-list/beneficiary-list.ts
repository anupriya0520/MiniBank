// src/app/features/beneficiaries/beneficiary-list/beneficiary-list.component.ts
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AccountService } from '../../../core/services/account';
import { PopupService } from '../../../core/services/popup';
import{Router}from '@angular/router';
@Component({
  selector: 'app-beneficiary-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './beneficiary-list.html',
  styleUrl: './beneficiary-list.css'
})
export class BeneficiaryListComponent implements OnInit {
  accountService = inject(AccountService);
  popupService = inject(PopupService);
  router = inject(Router);

  accounts: any[] = [];
  beneficiaries: any[] = [];
  selectedAccountId: number | null = null;
  loadingAccounts = true;
  loadingBeneficiaries = false;

  ngOnInit() {
    this.accountService.getMyAccounts().subscribe({
      next: (res: any) => {
        this.accounts = res.data || [];
        this.loadingAccounts = false;
        if (this.accounts.length > 0) {
          this.selectedAccountId = this.accounts[0].id;
          this.loadBeneficiaries();
        }
      },
      error: () => {
        this.loadingAccounts = false;
        this.popupService.error('Error', 'Failed to load accounts.');
      }
    });
  }
  goToTransfer() {
  this.router.navigate(['/transactions/transfer']);
}
  onAccountChange(event: any) {
    this.selectedAccountId = +event.target.value;
    this.loadBeneficiaries();
  }

  loadBeneficiaries() {
    if (!this.selectedAccountId) return;
    this.loadingBeneficiaries = true;
    this.accountService.getBeneficiaries(this.selectedAccountId).subscribe({
      next: (res: any) => {
        this.beneficiaries = res.data || [];
        this.loadingBeneficiaries = false;
      },
      error: () => {
        this.loadingBeneficiaries = false;
        this.popupService.error('Error', 'Failed to load beneficiaries.');
      }
    });
  }

  confirmDelete(beneficiaryId: number, name: string) {
    this.popupService.confirm(
      'Remove Beneficiary',
      `Are you sure you want to remove "${name}" from your beneficiaries?`,
      () => this.deleteBeneficiary(beneficiaryId)
    );
  }

  deleteBeneficiary(beneficiaryId: number) {
    if (!this.selectedAccountId) return;
    this.accountService.deleteBeneficiary(this.selectedAccountId, beneficiaryId).subscribe({
      next: () => {
        this.popupService.success(
          'Removed',
          'Beneficiary removed successfully.',
          () => this.loadBeneficiaries()
        );
      },
      error: (err: any) => {
        this.popupService.error('Error', err?.error?.message || 'Failed to remove beneficiary.');
      }
    });
  }
}