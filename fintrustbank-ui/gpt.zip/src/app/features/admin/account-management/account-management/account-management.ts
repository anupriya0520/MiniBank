// src/app/features/admin/account-management/account-management.component.ts
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../../core/services/admin';
import { PopupService } from '../../../../core/services/popup';

@Component({
  selector: 'app-account-management',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './account-management.html',
  styleUrl: './account-management.css'
})
export class AccountManagementComponent implements OnInit {
  adminService = inject(AdminService);
  popupService = inject(PopupService);

  accounts: any[] = [];
  filteredAccounts: any[] = [];
  loading = true;
  searchTerm = '';

  ngOnInit() {
    this.loadAccounts();
  }

  loadAccounts() {
    this.loading = true;
    this.adminService.getAllAccounts().subscribe({
      next: (res: any) => {
        this.accounts = res.data || [];
        this.filteredAccounts = [...this.accounts];
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.popupService.error('Error', 'Failed to load accounts.');
      }
    });
  }

  onSearch(event: any) {
    this.searchTerm = event.target.value.toLowerCase();
    this.filteredAccounts = this.accounts.filter(a =>
      a.accountNumber.toLowerCase().includes(this.searchTerm)
    );
  }

  confirmDeactivate(accountId: number, accountNumber: string) {
    this.popupService.confirm(
      'Deactivate Account',
      `Are you sure you want to deactivate account ${accountNumber}? This action cannot be undone.`,
      () => this.deactivateAccount(accountId)
    );
  }

  deactivateAccount(accountId: number) {
    this.adminService.deactivateAccount(accountId).subscribe({
      next: () => {
        this.popupService.success(
          'Account Deactivated',
          'The account has been deactivated successfully.',
          () => this.loadAccounts()
        );
      },
      error: (err: any) => {
        this.popupService.error('Error', err?.error?.message || 'Failed to deactivate account.');
      }
    });
  }

  getStatusLabel(status: number): string {
    const map: any = { 1: 'Pending Activation', 2: 'Active', 3: 'Inactive', 4: 'Deactivated' };
    return map[status] || 'Unknown';
  }

  getStatusClass(status: number): string {
    const map: any = { 1: 'badge-warning', 2: 'badge-success', 3: 'badge-muted', 4: 'badge-danger' };
    return map[status] || 'badge-muted';
  }

  getAccountTypeLabel(type: number): string {
    const map: any = { 1: 'Savings', 2: 'Current', 3: 'Fixed Deposit' };
    return map[type] || 'Unknown';
  }
}