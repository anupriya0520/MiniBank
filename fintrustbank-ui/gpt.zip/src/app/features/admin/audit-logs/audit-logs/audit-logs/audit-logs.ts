// src/app/features/admin/audit-logs/audit-logs.component.ts
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../../../core/services/admin';
import { PopupService } from '../../../../../core/services/popup';

@Component({
  selector: 'app-audit-logs',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './audit-logs.html',
  styleUrl: './audit-logs.css'
})
export class AuditLogsComponent implements OnInit {
  adminService = inject(AdminService);
  popupService = inject(PopupService);

  logs: any[] = [];
  filteredLogs: any[] = [];
  loading = true;
  searchTerm = '';

  ngOnInit() {
    this.loadLogs();
  }

  loadLogs() {
    this.loading = true;
    this.adminService.getAuditLogs().subscribe({
      next: (res: any) => {
        this.logs = res.data || [];
        this.filteredLogs = [...this.logs];
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.popupService.error('Error', 'Failed to load audit logs.');
      }
    });
  }

  onSearch(event: any) {
    const term = event.target.value.toLowerCase();
    this.filteredLogs = this.logs.filter(log =>
      log.action?.toLowerCase().includes(term) ||
      log.entity?.toLowerCase().includes(term) ||
      log.userName?.toLowerCase().includes(term) ||
      log.details?.toLowerCase().includes(term)
    );
  }
}