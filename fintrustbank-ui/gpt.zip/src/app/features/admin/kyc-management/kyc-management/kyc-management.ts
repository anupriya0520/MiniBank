// src/app/features/admin/kyc-management/kyc-management.component.ts
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../../../core/services/admin';
import { PopupService } from '../../../../core/services/popup';

@Component({
  selector: 'app-kyc-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './kyc-management.html',
  styleUrl: './kyc-management.css'
})
export class KycManagementComponent implements OnInit {
  adminService = inject(AdminService);
  popupService = inject(PopupService);
  fb = inject(FormBuilder);

  kycList: any[] = [];
  filteredList: any[] = [];
  loading = true;
  activeFilter: 'all' | 'pending' | 'approved' | 'rejected' = 'pending';

  reviewForm!: FormGroup;
  selectedKyc: any = null;
  showReviewPanel = false;
  submitting = false;

  ngOnInit() {
    this.reviewForm = this.fb.group({
      isApproved: [true],
      rejectionReason: ['']
    });

    this.loadKyc();
  }

  loadKyc() {
    this.loading = true;
    this.adminService.getAllKyc().subscribe({
      next: (res: any) => {
        this.kycList = res.data || [];
        this.applyFilter();
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.popupService.error('Error', 'Failed to load KYC requests.');
      }
    });
  }

  applyFilter() {
    if (this.activeFilter === 'all') {
      this.filteredList = this.kycList;
    } else {
      const map: any = { pending: 1, approved: 2, rejected: 3 };
      this.filteredList = this.kycList.filter(k => k.status === map[this.activeFilter]);
    }
  }

  setFilter(filter: 'all' | 'pending' | 'approved' | 'rejected') {
    this.activeFilter = filter;
    this.applyFilter();
  }

  getCount(status: 'all' | 'pending' | 'approved' | 'rejected'): number {
    if (status === 'all') return this.kycList.length;
    const map: any = { pending: 1, approved: 2, rejected: 3 };
    return this.kycList.filter(k => k.status === map[status]).length;
  }

  openReview(kyc: any) {
    this.selectedKyc = kyc;
    this.showReviewPanel = true;
    this.reviewForm.reset({ isApproved: true, rejectionReason: '' });
  }

  closeReview() {
    this.showReviewPanel = false;
    this.selectedKyc = null;
  }

  onApprovalChange() {
    const isApproved = this.reviewForm.value.isApproved;
    const rejReason = this.reviewForm.get('rejectionReason');
    if (!isApproved) {
      rejReason?.setValidators([Validators.required]);
    } else {
      rejReason?.clearValidators();
    }
    rejReason?.updateValueAndValidity();
  }

  submitReview() {
    if (this.reviewForm.invalid) {
      this.reviewForm.markAllAsTouched();
      return;
    }

    const { isApproved, rejectionReason } = this.reviewForm.value;
    const action = isApproved ? 'approve' : 'reject';

    this.popupService.confirm(
      `Confirm ${isApproved ? 'Approval' : 'Rejection'}`,
      `Are you sure you want to ${action} KYC for ${this.selectedKyc?.fullName}?`,
      () => {
        this.submitting = true;
        this.adminService.reviewKyc(this.selectedKyc.id, { isApproved, rejectionReason }).subscribe({
          next: () => {
            this.submitting = false;
            this.closeReview();
            this.popupService.success(
              `KYC ${isApproved ? 'Approved' : 'Rejected'}`,
              isApproved
                ? 'KYC approved. Bank account has been created for the user.'
                : 'KYC rejected successfully.',
              () => this.loadKyc()
            );
          },
          error: (err: any) => {
            this.submitting = false;
            this.popupService.error('Error', err?.error?.message || 'Could not process review.');
          }
        });
      }
    );
  }

  getStatusLabel(status: number): string {
    const map: any = { 1: 'Pending', 2: 'Approved', 3: 'Rejected' };
    return map[status] || 'Unknown';
  }

  getStatusClass(status: number): string {
    const map: any = { 1: 'badge-warning', 2: 'badge-success', 3: 'badge-danger' };
    return map[status] || 'badge-muted';
  }

  getAccountTypeLabel(type: number): string {
    const map: any = { 1: 'Savings', 2: 'Current', 3: 'Fixed Deposit' };
    return map[type] || 'Unknown';
  }
}