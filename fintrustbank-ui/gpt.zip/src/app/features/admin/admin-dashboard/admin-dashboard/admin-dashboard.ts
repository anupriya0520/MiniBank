// src/app/features/admin/admin-dashboard/admin-dashboard.component.ts
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AdminService } from '../../../../core/services/admin';
import { PopupService } from '../../../../core/services/popup';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './admin-dashboard.html',
  styleUrl: './admin-dashboard.css'
})
export class AdminDashboardComponent implements OnInit {
  adminService = inject(AdminService);
  popupService = inject(PopupService);

  dashboard: any = null;
  recentLogs: any[] = [];
  loading = true;

  ngOnInit() {
    this.loadDashboard();
  }

  loadDashboard() {
    this.loading = true;
    this.adminService.getDashboard().subscribe({
      next: (res: any) => {
        this.dashboard = res.data;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.popupService.error('Error', 'Failed to load admin dashboard.');
      }
    });

    this.adminService.getAuditLogs().subscribe({
      next: (res: any) => {
        this.recentLogs = (res.data || []).slice(0, 6);
      },
      error: () => { this.recentLogs = []; }
    });
  }
}