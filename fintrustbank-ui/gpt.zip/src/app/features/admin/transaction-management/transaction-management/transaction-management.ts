// src/app/features/admin/transaction-management/transaction-management.component.ts
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../../../core/services/admin';
import { PopupService } from '../../../../core/services/popup';

@Component({
  selector: 'app-transaction-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './transaction-management.html',
  styleUrl: './transaction-management.css'
})
export class TransactionManagementComponent implements OnInit {
  adminService = inject(AdminService);
  popupService = inject(PopupService);
  fb = inject(FormBuilder);

  transactions: any[] = [];
  filteredTransactions: any[] = [];
  loading = true;
  activeFilter: 'all' | 'flagged' = 'all';

  flagForm!: FormGroup;
  selectedTx: any = null;
  showFlagPanel = false;
  submitting = false;

  ngOnInit() {
    this.flagForm = this.fb.group({
      reason: ['', Validators.required]
    });
    this.loadTransactions();
  }
  getFlaggedCount(): number {
  return this.transactions.filter(t => t.isFlagged).length;
}
  loadTransactions() {
    this.loading = true;
    this.adminService.getAllTransactions().subscribe({
      next: (res: any) => {
        this.transactions = res.data || [];
        this.applyFilter();
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.popupService.error('Error', 'Failed to load transactions.');
      }
    });
  }

  applyFilter() {
    this.filteredTransactions = this.activeFilter === 'flagged'
      ? this.transactions.filter(t => t.isFlagged)
      : this.transactions;
  }

  setFilter(filter: 'all' | 'flagged') {
    this.activeFilter = filter;
    this.applyFilter();
  }

  openFlag(tx: any) {
    this.selectedTx = tx;
    this.showFlagPanel = true;
    this.flagForm.reset();
  }

  closeFlag() {
    this.showFlagPanel = false;
    this.selectedTx = null;
  }

  submitFlag() {
    if (this.flagForm.invalid) {
      this.flagForm.markAllAsTouched();
      return;
    }

    this.popupService.confirm(
      'Flag Transaction',
      'Are you sure you want to flag this transaction? The account flag count will increase.',
      () => {
        this.submitting = true;
        this.adminService.flagTransaction(this.selectedTx.id, { reason: this.flagForm.value.reason }).subscribe({
          next: () => {
            this.submitting = false;
            this.closeFlag();
            this.popupService.success(
              'Transaction Flagged',
              'Transaction has been flagged. Account flag count updated.',
              () => this.loadTransactions()
            );
          },
          error: (err: any) => {
            this.submitting = false;
            this.popupService.error('Error', err?.error?.message || 'Could not flag transaction.');
          }
        });
      }
    );
  }

  getTxTypeLabel(type: number): string {
    const map: any = { 1: 'Deposit', 2: 'Withdrawal', 3: 'Transfer Out', 4: 'Transfer In' };
    return map[type] || 'Unknown';
  }

  getTxTypeClass(type: number): string {
    const map: any = { 1: 'badge-success', 2: 'badge-danger', 3: 'badge-warning', 4: 'badge-info' };
    return map[type] || 'badge-muted';
  }

  getTxStatusLabel(status: number): string {
    const map: any = { 1: 'Pending', 2: 'Completed', 3: 'Failed', 4: 'Flagged' };
    return map[status] || 'Unknown';
  }

  getTxStatusClass(status: number): string {
    const map: any = { 1: 'badge-warning', 2: 'badge-success', 3: 'badge-danger', 4: 'badge-danger' };
    return map[status] || 'badge-muted';
  }
}