// src/app/features/accounts/set-pin/set-pin.component.ts
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AccountService } from '../../../../core/services/account';
import { PopupService } from '../../../../core/services/popup';

@Component({
  selector: 'app-set-pin',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './set-pin.html',
  styleUrl: './set-pin.css'
})
export class SetPinComponent implements OnInit {
  fb = inject(FormBuilder);
  accountService = inject(AccountService);
  popupService = inject(PopupService);
  route = inject(ActivatedRoute);
  router = inject(Router);

  setPinForm!: FormGroup;
  updatePinForm!: FormGroup;
  accounts: any[] = [];
  loading = false;
  loadingAccounts = true;
  activeTab: 'set' | 'update' = 'set';

  ngOnInit() {
    this.setPinForm = this.fb.group({
      accountId: ['', Validators.required],
      pin: ['', [Validators.required, Validators.pattern(/^\d{4,6}$/)]]
    });

    this.updatePinForm = this.fb.group({
      accountId: ['', Validators.required],
      oldPin: ['', Validators.required],
      newPin: ['', [Validators.required, Validators.pattern(/^\d{4,6}$/)]]
    });

    this.accountService.getMyAccounts().subscribe({
      next: (res: any) => {
        this.accounts = res.data || [];
        this.loadingAccounts = false;

        const accountId = this.route.snapshot.queryParams['accountId'];
        if (accountId) {
          this.setPinForm.patchValue({ accountId });
          this.updatePinForm.patchValue({ accountId });
        } else if (this.accounts.length > 0) {
          this.setPinForm.patchValue({ accountId: this.accounts[0].id });
          this.updatePinForm.patchValue({ accountId: this.accounts[0].id });
        }
      },
      error: () => {
        this.loadingAccounts = false;
        this.popupService.error('Error', 'Failed to load accounts.');
      }
    });
  }

  switchTab(tab: 'set' | 'update') {
    this.activeTab = tab;
  }

  onSetPin() {
    if (this.setPinForm.invalid) {
      this.setPinForm.markAllAsTouched();
      return;
    }

    const { accountId, pin } = this.setPinForm.value;
    this.loading = true;

    this.accountService.setTransferPin(accountId, { pin }).subscribe({
      next: () => {
        this.loading = false;
        this.popupService.success(
          'PIN Set Successfully',
          'Your transfer PIN has been set. Transfers are now enabled.',
          () => this.router.navigate(['/accounts'])
        );
      },
      error: (err: any) => {
        this.loading = false;
        this.popupService.error('Failed', err?.error?.message || 'Could not set PIN.');
      }
    });
  }

  onUpdatePin() {
    if (this.updatePinForm.invalid) {
      this.updatePinForm.markAllAsTouched();
      return;
    }

    const { accountId, oldPin, newPin } = this.updatePinForm.value;
    this.loading = true;

    this.accountService.updateTransferPin(accountId, { oldPin, newPin }).subscribe({
      next: () => {
        this.loading = false;
        this.popupService.success(
          'PIN Updated',
          'Your transfer PIN has been updated successfully.',
          () => this.router.navigate(['/accounts'])
        );
      },
      error: (err: any) => {
        this.loading = false;
        this.popupService.error('Failed', err?.error?.message || 'Could not update PIN.');
      }
    });
  }
}