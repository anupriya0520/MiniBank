// src/app/features/accounts/account-list/account-list.component.ts
import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AccountService } from '../../../../core/services/account';
import { PopupService } from '../../../../core/services/popup';

@Component({
  selector: 'app-account-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './account-list.html',
  styleUrl: './account-list.css'
})
export class AccountListComponent implements OnInit {
  accountService = inject(AccountService);
  popupService = inject(PopupService);

  accounts: any[] = [];
  loading = true;

  ngOnInit() {
    this.loadAccounts();
  }

  loadAccounts() {
    this.loading = true;
    this.accountService.getMyAccounts().subscribe({
      next: (res: any) => {
        this.accounts = res.data || [];
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.popupService.error('Error', 'Failed to load accounts.');
      }
    });
  }

  getStatusLabel(status: number): string {
    const map: any = { 1: 'Pending Activation', 2: 'Active', 3: 'Inactive', 4: 'Deactivated' };
    return map[status] || 'Unknown';
  }

  getStatusClass(status: number): string {
    const map: any = { 1: 'badge-warning', 2: 'badge-success', 3: 'badge-muted', 4: 'badge-danger' };
    return map[status] || 'badge-muted';
  }

  getAccountTypeLabel(type: number): string {
    const map: any = { 1: 'Savings', 2: 'Current', 3: 'Fixed Deposit' };
    return map[type] || 'Unknown';
  }
}